"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var MyGame;
(function (MyGame) {
    var Ball = /** @class */ (function () {
        function Ball(x, y, radius, stage) {
            this.graphics = new PIXI.Graphics;
            this.x = x;
            this.y = y;
            this.height = 2 * radius;
            this.width = 2 * radius;
            this.stage = stage;
            this.drawBall();
        }
        Ball.prototype.drawBall = function () {
            this.graphics.beginFill(0xffffff);
            this.graphics.drawCircle(this.x, this.y, this.width / 2);
            this.graphics.endFill();
            this.stage.stage.addChild(this.graphics);
            this.graphics.interactive = true;
            return this;
        };
        Ball.prototype.moveTo = function (x, y) {
            this.x = x;
            this.y = y;
            this.graphics.position.x += x;
            this.graphics.position.y += y;
        };
        return Ball;
    }());
    MyGame.Ball = Ball;
})(MyGame || (MyGame = {}));
var MyGame;
(function (MyGame) {
    var Edges = /** @class */ (function () {
        function Edges(x, y, height, width, stage) {
            this.graphics = new PIXI.Graphics;
            this.x = x;
            this.y = y;
            this.height = height;
            this.width = width;
            this.stage = stage;
            this.drawEdges();
        }
        Edges.prototype.drawEdges = function () {
            this.graphics.beginFill(0xffffff);
            this.graphics.drawRect(this.x, this.y, this.width, this.height);
            this.graphics.endFill();
            this.stage.stage.addChild(this.graphics);
            return this;
        };
        Edges.prototype.moveTo = function (x, y) { };
        return Edges;
    }());
    MyGame.Edges = Edges;
})(MyGame || (MyGame = {}));
var MyGame;
(function (MyGame) {
    var GameController = /** @class */ (function () {
        function GameController() {
            this.app = new PIXI.Application(window.innerWidth / 2, window.innerHeight / 2, { transparent: true });
            this.app.view.style.display = "block";
            this.app.view.style.marginLeft = window.innerWidth / 4 + "px";
            this.app.view.style.marginTop = innerHeight / 4 + "px";
            this.app.view.style.marginRight = innerWidth / 4 + "px";
            this.app.view.style.marginBottom = innerHeight / 4 + "px";
            document.body.appendChild(this.app.view);
            this.start();
            this.app.ticker.add(this.Update.bind(this));
        }
        GameController.prototype.start = function () { };
        GameController.prototype.Update = function (delta) { };
        return GameController;
    }());
    MyGame.GameController = GameController;
})(MyGame || (MyGame = {}));
var MyGame;
(function (MyGame) {
    var Ledges = /** @class */ (function () {
        function Ledges(x, y, height, width, stage) {
            this.graphics = new PIXI.Graphics;
            this.x = x;
            this.y = y;
            this.height = height;
            this.width = width;
            this.stage = stage;
            this.drawLedge();
        }
        Ledges.prototype.drawLedge = function () {
            this.graphics.beginFill(0xffffff);
            this.graphics.drawRect(this.x, this.y, this.width, this.height);
            this.graphics.endFill();
            this.stage.stage.addChild(this.graphics);
            return this;
        };
        Ledges.prototype.moveTo = function (x, y) {
            this.x = x;
            this.y = y;
            this.graphics.position.y += y;
        };
        return Ledges;
    }());
    MyGame.Ledges = Ledges;
})(MyGame || (MyGame = {}));
var MyGame;
(function (MyGame) {
    var PingPongGameController = /** @class */ (function (_super) {
        __extends(PingPongGameController, _super);
        function PingPongGameController() {
            var _this_1 = _super !== null && _super.apply(this, arguments) || this;
            _this_1.moveVelocityX = 2;
            _this_1.moveVelocityY = 2;
            return _this_1;
        }
        PingPongGameController.prototype.start = function () {
            var displayWidth = this.app.screen.width;
            var displayHeight = this.app.screen.height;
            this.ball = new MyGame.Ball(displayWidth / 2 - 50, displayHeight / 60, displayHeight / 60, this.app);
            this.EdgesT = new MyGame.Edges(0, 0, displayWidth, displayHeight / 300, this.app);
            this.EdgesL = new MyGame.Edges(0, 0, displayWidth / 400, displayHeight, this.app);
            this.EdgesR = new MyGame.Edges(displayWidth, 0, -2, displayHeight, this.app);
            this.EdgesB = new MyGame.Edges(0, displayHeight, displayWidth, -2, this.app);
            this.Ledge1 = new MyGame.Ledges(displayWidth / 80, displayHeight / 60, displayWidth / 80, displayHeight / 4, this.app);
            this.Ledge2 = new MyGame.Ledges(displayWidth - displayWidth / 40, displayHeight / 60, displayWidth / 80, displayHeight / 4, this.app);
        };
        PingPongGameController.prototype.Update = function (delta) {
            var _this = this;
            //move ball 
            moveBall();
            function moveBall() {
                _this.ball.moveTo(_this.moveVelocityX, _this.moveVelocityY);
            }
            //move paddle 
            movePaddle();
            function movePaddle() {
                movePaddle1();
                movePaddle2();
                function movePaddle1() {
                    _this.Ledge1.moveTo(_this.Ledge1.x, _this.moveVelocityY);
                }
                function movePaddle2() {
                    // let y2 = _this.paddle2.y;
                    var x1 = _this.app.renderer.plugins.interaction.mouse.global.x;
                    var y1 = _this.app.renderer.plugins.interaction.mouse.global.y;
                    if (y1 < 0)
                        y1 = 0 + _this.Ledge2.height / 2;
                    if (y1 > _this.app.screen.height)
                        y1 = _this.app.screen.height - _this.Ledge2.height / 2;
                    _this.Ledge2.y = y1;
                    _this.Ledge2.graphics.position.y = y1;
                    // _this.paddle2.moveTo(_this.paddle2.x, y1-_this.paddle2.height / 2);
                }
            }
            // handle  collision 
            //update stage
        };
        return PingPongGameController;
    }(MyGame.GameController));
    MyGame.PingPongGameController = PingPongGameController;
})(MyGame || (MyGame = {}));
