declare namespace MyGame {
        export interface iView{
          x:number;
          y:number;
          width:number;
          height:number;
          stage:any;
        
        moveTo(x: number,y: number):void;
        }
}