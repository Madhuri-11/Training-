namespace MyGame{
    export class Edges implements iView{

                public x:number;
                public y:number;
                public height:number;
                public width:number;
                public stage:any;
                public graphics = new PIXI.Graphics;
        
            
            constructor(x:number,y:number,height:number,width:number,stage:any){
                this.x=x;
                this.y=y;
                this.height=height;
                this.width=width;
                this.stage=stage;
                this.drawEdges();
            }
            private drawEdges():Edges{
                    this.graphics.beginFill(0xffffff);
                    this.graphics.drawRect(this.x, this.y, this.width, this.height);
                    this.graphics.endFill();
                    this.stage.stage.addChild(this.graphics);
                    return this;
            }
        
            moveTo(x: number, y: number) {}
        }
    }
                
    
