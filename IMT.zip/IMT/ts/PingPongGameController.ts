namespace MyGame {
    export class PingPongGameController extends GameController {
         app!: PIXI.Application;
         Ledge1!: Ledges  ;
         Ledge2!: Ledges  ;
         EdgesT!: Edges  ;
         EdgesR!: Edges  ;
         EdgesB!: Edges  ;
         EdgesL!: Edges; 
         ball!: Ball;
         moveVelocityX:number=2;
         moveVelocityY:number=2;

        start() {
        var displayWidth: number = this.app.screen.width;
        var displayHeight: number = this.app.screen.height;
            this.ball = new Ball(displayWidth/2-50, displayHeight/60, displayHeight/60, this.app);
            this.EdgesT = new Edges(0, 0, displayWidth, displayHeight/300, this.app);
            this.EdgesL = new Edges(0, 0, displayWidth/400, displayHeight, this.app);
            this.EdgesR = new Edges(displayWidth, 0, -2, displayHeight, this.app);
            this.EdgesB = new Edges(0, displayHeight, displayWidth, -2, this.app);
            this.Ledge1 = new Ledges(displayWidth/80, displayHeight/60, displayWidth/80, displayHeight/4, this.app);
            this.Ledge2 = new Ledges(displayWidth-displayWidth/40,displayHeight/60 , displayWidth/80,displayHeight/4, this.app);

        }

        Update(delta :number) {

        let _this = this; 
        //move ball 
        moveBall();

        function moveBall(): any {
            _this.ball.moveTo(_this.moveVelocityX, _this.moveVelocityY);
        }


        //move paddle 
    movePaddle();
    function movePaddle() {
        movePaddle1();
        movePaddle2();
        
    function movePaddle1() {
        _this.Ledge1.moveTo(_this.Ledge1.x, _this.moveVelocityY);
    }


    function movePaddle2() {
    // let y2 = _this.paddle2.y;
        let x1 =  _this.app.renderer.plugins.interaction.mouse.global.x;
        let y1 =  _this.app.renderer.plugins.interaction.mouse.global.y;
        if(y1 < 0)
            y1 = 0 + _this.Ledge2.height / 2;
    if(y1 > _this.app.screen.height)
            y1 = _this.app.screen.height-_this.Ledge2.height/2;

        _this.Ledge2.y = y1;
        _this.Ledge2.graphics.position.y = y1;

    // _this.paddle2.moveTo(_this.paddle2.x, y1-_this.paddle2.height / 2);

    }
    }


    // handle  collision 

    //update stage
    


   
  
    }


}
}