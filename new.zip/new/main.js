window.onload = function  move() {
    let elem = document.getElementById("ScrollDiv");   
    let width = 1;
    let  id = setInterval(frame, 50);
    function frame() {
      if (width >= 80) {
        clearInterval(id);
      } else {
        width++; 
        elem.style.width = width + '%'; 
      }
    }
  } 