"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var PingPongGame;
(function (PingPongGame) {
    var Ball = /** @class */ (function () {
        function Ball(x, y, radius, stage) {
            this.graphics = new PIXI.Graphics();
            this.x = x;
            this.y = y;
            this.height = 2 * radius;
            this.width = 2 * radius;
            this.stage = stage;
            this.drawBall();
        }
        Ball.prototype.drawBall = function () {
            this.graphics.beginFill(0xffffff);
            this.graphics.drawCircle(this.x, this.y, this.width / 2);
            this.graphics.endFill();
            this.stage.stage.addChild(this.graphics);
            this.graphics.interactive = true;
            return this;
        };
        Ball.prototype.moveTo = function (x, y) {
            this.x = x;
            this.y = y;
            this.graphics.position.x += x;
            this.graphics.position.y += y;
        };
        return Ball;
    }());
    PingPongGame.Ball = Ball;
})(PingPongGame || (PingPongGame = {}));
var PingPongGame;
(function (PingPongGame) {
    var Bound = /** @class */ (function () {
        function Bound(x, y, width, height, stage) {
            this.graphics = new PIXI.Graphics();
            this.x = x;
            this.y = y;
            this.height = height;
            this.width = width;
            this.stage = stage;
            this.drawimg();
        }
        Bound.prototype.drawimg = function () {
            this.graphics.beginFill(0xffffff);
            this.graphics.drawRect(this.x, this.y, this.width, this.height);
            this.graphics.endFill();
            this.stage.stage.addChild(this.graphics);
            this.graphics.interactive = true;
            return this;
        };
        Bound.prototype.moveTo = function (x, y) {
        };
        return Bound;
    }());
    PingPongGame.Bound = Bound;
})(PingPongGame || (PingPongGame = {}));
var PingPongGame;
(function (PingPongGame) {
    var Collider = /** @class */ (function () {
        function Collider() {
        }
        Collider.prototype.isCollide = function (object1, object2, handler) {
            if (!(((object1.y + object1.height) < object2.y) ||
                ((object1.y + object1.height) > object2.y) ||
                ((object1.x + object1.width) < object2.x) ||
                ((object1.x + object1.width) > object2.x))) {
                handler();
            }
        };
        return Collider;
    }());
    PingPongGame.Collider = Collider;
})(PingPongGame || (PingPongGame = {}));
var PingPongGame;
(function (PingPongGame) {
    var GameController = /** @class */ (function () {
        function GameController() {
            this.app = new PIXI.Application(window.innerWidth / 2, window.innerHeight / 2, { transparent: true });
            this.app.view.style.display = "block";
            this.app.view.style.marginLeft = window.innerWidth / 4 + "px";
            this.app.view.style.marginTop = innerHeight / 4 + "px";
            this.app.view.style.marginRight = innerWidth / 4 + "px";
            this.app.view.style.marginBottom = innerHeight / 4 + "px";
            document.body.appendChild(this.app.view);
            this.start();
            this.app.ticker.add(this.makeUpdation.bind(this));
        }
        GameController.prototype.start = function () { };
        GameController.prototype.makeUpdation = function (delta) { };
        return GameController;
    }());
    PingPongGame.GameController = GameController;
})(PingPongGame || (PingPongGame = {}));
var PingPongGame;
(function (PingPongGame) {
    var Paddle = /** @class */ (function () {
        function Paddle(x, y, width, height, stage) {
            this.graphics = new PIXI.Graphics();
            this.x = x;
            this.y = y;
            this.height = height;
            this.width = width;
            this.stage = stage;
            this.drawPaddle();
        }
        Paddle.prototype.drawPaddle = function () {
            this.graphics.beginFill(0xffffff);
            this.graphics.drawRect(this.x, this.y, this.width, this.height);
            this.graphics.endFill();
            this.stage.stage.addChild(this.graphics);
            return this;
        };
        Paddle.prototype.moveTo = function (x, y) {
            this.x = x;
            this.y = y;
            this.graphics.position.y += y;
        };
        return Paddle;
    }());
    PingPongGame.Paddle = Paddle;
})(PingPongGame || (PingPongGame = {}));
/// <reference path="paddle.ts" />
/// <reference path="Ball.ts" />
var PingPongGame;
(function (PingPongGame) {
    var PingPongGameController = /** @class */ (function (_super) {
        __extends(PingPongGameController, _super);
        function PingPongGameController() {
            var _this_1 = _super !== null && _super.apply(this, arguments) || this;
            _this_1.moveVelocityX = 2;
            _this_1.moveVelocityY = 2;
            return _this_1;
        }
        PingPongGameController.prototype.start = function () {
            var screenWidth = this.app.screen.width;
            var screenHeight = this.app.screen.height;
            this.ball = new PingPongGame.Ball(screenWidth / 2 - 50, screenHeight / 60, screenHeight / 60, this.app);
            this.boundUp = new PingPongGame.Bound(0, 0, screenWidth, screenHeight / 300, this.app);
            this.boundLeft = new PingPongGame.Bound(0, 0, screenWidth / 400, screenHeight, this.app);
            this.boundRight = new PingPongGame.Bound(screenWidth, 0, -2, screenHeight, this.app);
            this.boundDown = new PingPongGame.Bound(0, screenHeight, screenWidth, -2, this.app);
            this.paddle1 = new PingPongGame.Paddle(screenWidth / 80, screenHeight / 60, screenWidth / 80, screenHeight / 4, this.app);
            this.paddle2 = new PingPongGame.Paddle(screenWidth - screenWidth / 40, screenHeight / 60, screenWidth / 80, screenHeight / 4, this.app);
            this.collider = new PingPongGame.Collider();
        };
        PingPongGameController.prototype.makeUpdation = function (delta) {
            var _this = this;
            //move ball 
            moveBall();
            function moveBall() {
                _this.ball.moveTo(_this.moveVelocityX, _this.moveVelocityY);
            }
            //move paddle 
            movePaddle();
            function movePaddle() {
                movePaddle1();
                movePaddle2();
                function movePaddle1() {
                    _this.paddle1.moveTo(_this.paddle1.x, _this.moveVelocityY);
                }
                function movePaddle2() {
                    // let y2 = _this.paddle2.y;
                    var x1 = _this.app.renderer.plugins.interaction.mouse.global.x;
                    var y1 = _this.app.renderer.plugins.interaction.mouse.global.y;
                    if (y1 < 0)
                        y1 = 0 + _this.paddle2.height / 2;
                    if (y1 > _this.app.screen.height)
                        y1 = _this.app.screen.height - _this.paddle2.height / 2;
                    _this.paddle2.y = y1;
                    _this.paddle2.graphics.position.y = y1;
                    // _this.paddle2.moveTo(_this.paddle2.x, y1-_this.paddle2.height / 2);
                }
            }
            // handle  collision 
            //update stage 
            updateStage();
            function updateStage() {
                _this.collider.isCollide(_this.paddle1, _this.ball, function () { });
            }
        };
        return PingPongGameController;
    }(PingPongGame.GameController));
    PingPongGame.PingPongGameController = PingPongGameController;
})(PingPongGame || (PingPongGame = {}));
/// <reference path="./PingPongGameController.ts" />
var PingPongGame;
(function (PingPongGame) {
    var MainGame = /** @class */ (function () {
        function MainGame() {
            this.gc = new PingPongGame.PingPongGameController();
        }
        return MainGame;
    }());
    PingPongGame.MainGame = MainGame;
    var ob1 = new MainGame();
})(PingPongGame || (PingPongGame = {}));
