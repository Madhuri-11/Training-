namespace PingPongGame {
    export class GameController {
    public app:PIXI.Application;

constructor () {
    this.app = new PIXI.Application(window.innerWidth / 2, window.innerHeight / 2,
    { transparent:true });
    this.app.view.style.display = "block";
    this.app.view.style.marginLeft = window.innerWidth / 4 + "px";
    this.app.view.style.marginTop = innerHeight / 4 + "px";
    this.app.view.style.marginRight = innerWidth / 4 + "px";
    this.app.view.style.marginBottom = innerHeight / 4 + "px";
    document.body.appendChild(this.app.view);
    this.start();
    this.app.ticker.add(this.makeUpdation.bind(this));
}
   

    public start(){}
    public makeUpdation(delta:number) {}
}
    
}