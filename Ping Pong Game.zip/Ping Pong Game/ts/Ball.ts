namespace PingPongGame {
    export class Ball implements iRigidBody {

        public  x: number;
        public  y: number;
        public height: number;
        public width: number;
        stage: any;
        public graphics = new PIXI.Graphics();

        constructor(x: number, y: number, radius: number ,stage: any) {
            this.x = x;
            this.y = y;
            this.height = 2*radius;
            this.width = 2*radius;
            this.stage = stage;
            this.drawBall();
        }
        private drawBall() {
            this.graphics.beginFill(0xffffff);
            this.graphics.drawCircle(this.x, this.y, this.width/2);
            this.graphics.endFill();
            this.stage.stage.addChild(this.graphics);
            this.graphics.interactive = true;
            return this;
            }
        moveTo(x: number, y: number) {
            this.x = x;
            this.y = y;
            this.graphics.position.x += x;
            this.graphics.position.y += y;
        }
    }
}