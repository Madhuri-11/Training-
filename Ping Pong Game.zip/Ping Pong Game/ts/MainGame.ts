/// <reference path="./PingPongGameController.ts" />
namespace PingPongGame {
    export class MainGame {
      gc: PingPongGameController;
    constructor() {
          this.gc = new PingPongGameController();        
         }}
    var ob1 = new MainGame();
    }