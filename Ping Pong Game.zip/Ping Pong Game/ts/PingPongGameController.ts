/// <reference path="paddle.ts" />
/// <reference path="Ball.ts" />

namespace PingPongGame {
    export class PingPongGameController extends GameController {
         collider!:Collider;
         app!: PIXI.Application;
         paddle1!: Paddle  ;
         paddle2!: Paddle  ;
         boundUp!: Bound  ;
         boundRight!: Bound  ;
         boundLeft!: Bound  ;
         boundDown!: Bound 
         ball!: Ball;
            moveVelocityX:number=2;
            moveVelocityY:number=2;

        start() {
        var screenWidth: number = this.app.screen.width;
        var screenHeight: number = this.app.screen.height;
            this.ball = new Ball(screenWidth/2-50, screenHeight/60, screenHeight/60, this.app);
            this.boundUp = new Bound(0, 0, screenWidth, screenHeight/300, this.app);
            this.boundLeft = new Bound(0, 0, screenWidth/400, screenHeight, this.app);
            this.boundRight = new Bound(screenWidth, 0, -2, screenHeight, this.app);
            this.boundDown = new Bound(0, screenHeight, screenWidth, -2, this.app);
            this.paddle1 = new Paddle(screenWidth/80, screenHeight/60, screenWidth/80, screenHeight/4, this.app);
            this.paddle2 = new Paddle(screenWidth-screenWidth/40,screenHeight/60 , screenWidth/80,screenHeight/4, this.app);
            this.collider = new Collider();
        }

    makeUpdation(delta :number) {

        let _this = this; 
        //move ball 
        moveBall();

        function moveBall(): any {
            _this.ball.moveTo(_this.moveVelocityX, _this.moveVelocityY);
        }


        //move paddle 
    movePaddle();
    function movePaddle() {
        movePaddle1();
        movePaddle2();
        
    function movePaddle1() {
        _this.paddle1.moveTo(_this.paddle1.x, _this.moveVelocityY);
    }


    function movePaddle2() {
    // let y2 = _this.paddle2.y;
        let x1 =  _this.app.renderer.plugins.interaction.mouse.global.x;
        let y1 =  _this.app.renderer.plugins.interaction.mouse.global.y;
        if(y1 < 0)
            y1 = 0 + _this.paddle2.height / 2;
    if(y1 > _this.app.screen.height)
            y1 = _this.app.screen.height-_this.paddle2.height/2;

        _this.paddle2.y = y1;
        _this.paddle2.graphics.position.y = y1;

    // _this.paddle2.moveTo(_this.paddle2.x, y1-_this.paddle2.height / 2);

    }
    }


    // handle  collision 

    //update stage 

    updateStage();

    function updateStage() {
_this.collider.isCollide(_this.paddle1,_this.ball,function(){})

    }
   


   
  
    }


}
}